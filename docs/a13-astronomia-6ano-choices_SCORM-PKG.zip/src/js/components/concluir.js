export default{name:"Concluir",template:`
    <div id="concluir" class="pb-144 pt-80 scrollspy flex--justify-center" >
       
        <a data-aos="zoom-out" href="#/" id="finishButton" class="btn-large filled waves-effect waves-light bubbly-button">Concluir
          <span class="ml-8 pb-8 material-symbols-rounded"> check </span>
        </a>
        
    </div>
    `};