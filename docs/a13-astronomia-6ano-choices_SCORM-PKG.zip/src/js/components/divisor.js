export default{name:"Divisor",props:{src:String,d_class:String},template:`
     <div class="divisor" :class="[d_class]">
        <img
          :src="src"
          alt="Divisor de onda"
        />
      </div>
    `};