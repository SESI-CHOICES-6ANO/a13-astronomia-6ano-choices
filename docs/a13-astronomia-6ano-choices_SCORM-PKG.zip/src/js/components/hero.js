export default{name:"Hero",template:`
    <div id="hero" class="scrollspy">
    <div class="container--medium">
      <div class="display1 center-align green-text">
        <slot></slot>
      </div>
    </div>
  </div>
    `};